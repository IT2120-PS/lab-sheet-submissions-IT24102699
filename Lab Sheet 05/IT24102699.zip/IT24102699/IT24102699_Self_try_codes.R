
                    #  Lab Exercise 5 (Descriptive Statistics)


getwd()
setwd("F:\\SLIIT\\_Year_02_\\Semester 01\\PS - Probability and Statistics\\Lab Practicals\\Lab 05\\IT24102699")
getwd()


# Importing the data set
data <- read.table("Data.txt" , header = TRUE, sep = ",")


# View the file in a separate window
fix(data)



# Attach the file into R. So, we can call the variables by their names.
attach (data)





          # PART 01

# Rename the variables (column headings) of the data set as X1 and X2
names(data) <- c("X1","X2")

# Attach the file into R again as we renamed the variables
attach(data)

# Obtain histogram for number of shareholders
hist(X2,main = "Histogram for Number of Shareholders")





          # PART 02

# "breaks" command --> Define number of classes we need in histograms, along with lower limit and upper limit.
# "right" command --> define whether classes have closed intervals or open intervals.

histogram <- hist(
                  X2, 
                  main = "Histogram with 7 Classes", 
                  breaks = seq(130, 270, length = 8), 
                  right = FALSE
                  )


# Check how each argument inside "hist" command works using "help" command as follows
?hist





          # PART 03

# Assign class limits of the frequency distribution into a variable called "breaks"
breaks <- round(histogram$breaks)


# Assign class frequencies of the histogram into a variable called "freq"
freq <- histogram$counts


# Assign mid point of each class into a variable called "mids"
mids <- histogram$mids


# Creating the variable called "Classes" for the frequency distribution
classes <- c()



# Creating a "for" loop to assign classes of the frequency distribution into "Classes" variable created above.
for (i in 1:(length(breaks) - 1)) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

# obtaining frequency distribution by combining the values of "Classes" & "freq" variables
# "cbind" command --> Used to merge the columns with same length
cbind(Classes = classes, Frequency = freq)





          # PART 04

# Draw frequency polygon to the same plot.
lines(mids,freq)

# Draw frequency polygon in a new plot.
plot(mids, 
     freq,
     type = "l",
     main = "Frequency Polygon for Shareholders",
     xlab = "Shareholders",
     ylab = "Frequency",
     ylim = c(0, max(freq)))





          # PART 05

cum.freq <- cumsum(freq)

      # cumsum() --> adds up frequencies one by one.
      
          # Example: if freq = (5, 10, 15), then cum.freq = (5, 15, 30).
      
      # This is needed to plot an ogive (cumulative frequency graph).



new <- c()

      # This just makes an empty vector called new.
      
      # It will store the cumulative frequencies but shifted so that the ogive starts at zero.



for(i in 1:length(breaks)) {
  if(i == 1) {
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

      # breaks = class boundaries (upper limits of each class).
      
      # The loop goes through each class.
      
      # For the first value, it stores 0 (because cumulative frequency starts at 0).
      
      # For all others, it stores the previous cumulative frequency.
      
      # So basically, new becomes the cumulative frequencies but shifted one step back, which makes the ogive start at the bottom-left.



plot(breaks, 
     new, 
     type = 'l', 
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Shareholders", 
     ylab = "Cumulative Frequency", 
     ylim = c(0, max(cum.freq)))

      # Draws a line graph (type = 'l') of cumulative frequency vs class boundary.
      
      # X-axis: number of Shareholders (class upper limits).
      
      # Y-axis: Cumulative Frequency.
      
      # Starts from 0 up to the maximum cumulative frequency.



cbind(Upper = breaks, CumFreq = new)

      # Combines two columns:
        
          # Upper → the class upper limits.
       
      # CumFreq → cumulative frequencies.
       
      # This creates a nice table to check the ogive data.






          
                                        # SUMMARY
          
          # PART 01 – Histogram (Basic)
          
              # A Histogram is a bar graph showing how data is distributed into intervals (classes).
              # Each bar’s height represents the frequency (number of observations) in that interval.
              # Useful for visualizing the overall distribution of data.
          

          
          # PART 02 – Histogram with Classes
          
              # Class intervals can be set using “breaks” (e.g., 130–150, 150–170, …).
              # Intervals can be left-closed and right-open ([a, b)).
              # This makes the histogram more structured and easier to interpret.
          
          

          # PART 03 – Frequency Distribution Table
           
              # From the histogram, we can form a frequency table with:
              # Class boundaries (breaks) → the limits of each class.
              # Frequencies (freq) → number of data values in each class.
              # Midpoints (mids) → the middle value of each class.
              # Class labels → e.g., [130,150), [150,170), etc.
              # The frequency table organizes raw data into a clear summary.
          

          
          # PART 04 – Frequency Polygon
          
              # A Frequency Polygon is a line graph made by connecting the midpoints of class intervals with their frequencies.
              # It shows the same information as a histogram but in a smooth, continuous line.
              # Useful for comparing distributions between two or more data sets.
          
           

          # PART 05 – Ogive (Cumulative Frequency Polygon)
          
              # An Ogive is a graph of cumulative frequencies.
              # Cumulative frequency = running total of frequencies (added step by step).
              # The ogive starts at 0 and increases until it reaches the total frequency.
              # The X-axis shows the upper class boundaries, and the Y-axis shows the cumulative frequency.
              # Useful for finding medians, quartiles, percentiles, and understanding how data accumulates across classes.
              
