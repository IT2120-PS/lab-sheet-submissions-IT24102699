                    # Lab Sheet 02


getwd()
setwd("F:/SLIIT/_Year_02_/Semester 01/PS - Probability and Statistics/Lab Practicals/Lab 02")
getwd()


          # Exercise


# Question 02

x <- 1:15
divisible_by_3 <- x %% 3 == 0
count <- sum(divisible_by_3)
print(count)



count <- 0
for (i in 1:15) {
  if (i %% 3 == 0) {
    count <- count + 1
  }
}
print(count)



sum((1:15) %% 3 == 0)





# Question 03
vector1 <- c(45, 12, 89, 64, 95, 33, 71)
max_value <- vector1[1]
max_index <- 1
for (i in 2:length(vector1)) {
  if (vector1[i] > max_value) {
    max_value <- vector1[i]
    max_index <- i
  }
}
print(max_index)





# Question 04
numbers <- c(34, 19, 88, 5, 61)
highest_value <- max(numbers)
index_of_highest <- match(highest_value, numbers)
print(index_of_highest)



number_series <- c(34, 19, 88, 5, 61)
which.max(number_series)










