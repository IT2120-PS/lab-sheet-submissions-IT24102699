                    # Set Working Directory

getwd()
setwd("F:/SLIIT/_Year_02_/Semester 01/PS - Probability and Statistics/Lab Practicals/Lab 02/IT24102699")
getwd()



                    # print() Function

print(1:3)
print(1:10)
print(107:196)



                    # Sample Function Examples

          # Basic sample()

print(sample(1:3))
print(sample(1:10))
print(sample(107:196))



print(sample(1:3,size=3,replace=FALSE))
print(sample(1:3,size=4,replace=FALSE))   # Error in sample.int(length(x), size, replace, prob) : cannot take a sample larger than the population when 'replace = FALSE'
print(sample(1:3,size=4,replace=TRUE))
print(sample(1:3,size=10,replace=TRUE))



print(sample(c(1:3,size=3,replace=FALSE))) 
print(sample(c(1:3,size=4,replace=FALSE)))     
print(sample(c(1:3,size=4,replace=TRUE)))  
print(sample(c(1:3,size=10,replace=TRUE)))

# size and replace got swallowed inside c() as extra elements, so sample() just shuffles a wrong vector.



print(sample(c(2,5,3),size=4,replace=TRUE))
print(sample(c(2,5,3),size=4,replace=FALSE))   # Error in sample.int(length(x), size, replace, prob) : cannot take a sample larger than the population when 'replace = FALSE'



print(sample(1:2,size=10,prob=c(0.3,0.7),replace=TRUE))
print(sample(1:2,size=10,prob=c(0.3,0.7),replace=FALSE))   # Error in sample.int(length(x), size, replace, prob) : cannot take a sample larger than the population when 'replace = FALSE'
print(sample(1:5,size=10,prob=c(0.3,0.7),replace=TRUE))   # Error in sample.int(length(x), size, replace, prob) : incorrect number of probabilities
print(sample(1:5,size=10,prob=c(0.3,0.7,0.2,0.9,0.3),replace=TRUE))
      # x = 1:5 → possible values are {1, 2, 3, 4, 5}.
      # 
      # size = 10 → pick 10 numbers.
      # 
      # prob = c(0.3, 0.7, 0.2, 0.9, 0.3) → probability weights:
      #   
      #     1 → 0.3
      # 
      #     2 → 0.7
      # 
      #     3 → 0.2
      # 
      #     4 → 0.9 (highest chance)
      # 
      #     5 → 0.3
      # 
      # replace = TRUE → can pick the same value more than once.
      # 
      # R does 10 independent draws, each time using the given probabilities.


          

          # Without print()
  

sample(1:3)
sample(1:10)
sample(15:25)



sample(1:3,size=3,replace=FALSE)
sample(1:10,size=3,replace=FALSE)
sample(1:10,size=10,replace=FALSE)
sample(15:25,size=3,replace=FALSE)



      # sample(1:3,size=3,replace=FALSE)
      # sample(1:3)
      #
      # In this case, both do exactly the same thing.
      # The difference is that the first is explicit, the second relies on defaults.
      # If you want fewer/more samples, or to allow repeats, you must specify size and/or replace.



sample(1:3,size=3,replace=TRUE)
sample(1:10,size=3,replace=TRUE)
sample(1:10,size=10,replace=TRUE)
sample(15:25,size=3,replace=TRUE)



sample(c(2,5,3),size=4,replace=TRUE)
sample(c(2,5,3),size=4,replace=FALSE)   # Error in sample.int(length(x), size, replace, prob) : cannot take a sample larger than the population when 'replace = FALSE'



sample(1:2,size=10,prob=c(0.3,0.7),replace=TRUE)



      # sample(1:2,size=10,prob=c(0.3,0.7),replace=TRUE)
      # This generates a random vector of 10 numbers.
      # If you run it at the console, R automatically prints the result.
      # If you run it inside a script (not at the console), R will generate the result but not display it unless it’s the last expression or you explicitly print it.
      # 
      # 
      # print(sample(1:2,size=10,prob=c(0.3,0.7),replace=TRUE))
      # This forces the result to print, no matter where you run it (console or script).
      # The output is the same random values, but prefixed with [1] (standard R print format).





                    # Control Statements

          # If statement

x <- 5
if (x > 0) {
  print("Positive number")
}



          # If-else statement

x <- -3
if (x > 0) {
  print("Positive number")
} else {
  print("Negative number")
}



          # Nested if

x <- 0
if (x > 0) {
  print("Positive")
} else if (x < 0) {
  print("Negative")
} else {
  print("Zero")
}



          # For loop

for (i in 1:5) {
  print(i)
}



          # While loop

count <- 1
while (count <= 5) {
  print(count)
  count <- count + 1
}





                    # Functions

# Without default values

add_numbers <- function(a, b) {
  return(a + b)
}
add_numbers(5, 3)



# With default values
multiply_numbers <- function(a = 2, b = 3) {
  return(a * b)
}
multiply_numbers()
multiply_numbers(4, 5)






                    # Importing Data

          # Import text file (Data1.txt)
data1 <- read.table("Data1.txt", header = TRUE, sep = ",")
print(data1)


          # Import CSV file (DATA 2.csv)
data2 <- read.csv("DATA 2.csv", header = TRUE)
print(data2)






                    # Exporting Data 

          # Create variables

Height <- c(50, 55, 60, 65, 70)
Weight <- c(45, 48, 52, 58, 65)


          # Create data frame

Sheep <- data.frame(Height, Weight)
print(Sheep)


          # Export to CSV

write.csv(Sheep, "Sheep.csv", row.names = FALSE)


          # Export to TXT
write.table(Sheep, "Sheep.txt", sep = "\t", row.names = FALSE)










