
                    # Lab Exercise 4 (Descriptive Statistics)


          # PART 01


# Setting the working directory
getwd()
setwd("F:\\SLIIT\\_Year_02_\\Semester 01\\PS - Probability and Statistics\\Lab Practicals\\Lab 04\\IT24102699")
getwd()


# Importing the data set
data <- read.table("DATA 4.txt", header = TRUE, sep = " ")


# View the file in a separate window
fix(data)


# Attach the file into R. So we can call the variables by their names.
attach(data)





          # PART 02


    # a) Box-Plot, Histogram and Stem-Leaf Plot 

# Obtaining Box Plots
boxplot(X1, main = "Box Plot for Team Attendence",outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box Plot for Team Salary",outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box Plot for Years",outline = TRUE, outpch = 8, horizontal = TRUE)


# Obtaining Histogram
hist(X1, ylab = "Frequency", xlab = "Team Attendence", main = "Histogram for Team Attendence")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")


# Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)



    # b) Mean, Median and Standard Deviation.

# Mean
mean(X1)
mean(X2)
mean(X3)


# Median
median(X1)
median(X2)
median(X3)


# Standard Deviation (SD)
sd(X1)
sd(X2)
sd(X3)



    # c) First and Third Quartile

# Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)


# Getting only five number summary for X1 variable
quantile(X1)


# Calling first Quartile of X1 using index value
quantile(X1)[2]



# Calling third Quartile of X1 using index value
quantile(X1)[4]



    # d)  Interquartile Range

# Obtaining Inter Quartile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)





          # PART 03


# Function to get the mode of a data set
get.mode<-function(y){
  counts<<-table(y)
  names(counts[counts == max(counts)])
}

# Obtaining the mode of a variable using the function defined above
get.mode(X3)

    # Explanation on how each command inside the function works
# Following command is to get the frequency table for the variable
table(X3)

# Following command will give the maximum frequency in the frequency table
max(counts)


    # Following command will check whether frequencies in the frequency table equals
# to the maximum frequency obtained
counts == max(counts)

# This extracts both value and the frequency which gives "TRUE" in earlier logical function
counts[counts == max(counts)]

# This extracts the value which gives maximum frequency (mode) in earlier logical function
names(counts[counts == max(counts)])





          # PART 04


# Function to check the existence of outliers of a data set
get.outliers <- function(z){
  q1 <- quantile(z) [2]
  q3 <- quantile(z) [4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print (paste("Upper Bound = ", ub))
  print (paste("Lower Bound = ", lb))
  print (paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}


# Checking the outliers of a variable using the function defined above
get.outliers (X1)
get.outliers (X2)
get.outliers (X3)






