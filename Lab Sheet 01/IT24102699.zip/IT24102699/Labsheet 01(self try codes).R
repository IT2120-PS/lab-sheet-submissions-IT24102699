print(100:150)
# This is my first R practical

# Get the current working directory
getwd()

# To set / change current working directory
# first create a ne folder in desktop named Lab 01
# Then copy the path of that folder and paste it here inside a " "
# Next if you're using \ then change it into \\
# Or you can use / 
# Then run the programme and then again check the current working directory using getwd()

# setwd("C:\\Users\\UsEr\\OneDrive\\Desktop\\Lab 01")

# Help ?<function or the object name>
?solve
help("data.frame")

# Installing Packages
install.packages("ggplot2")


# Scalar Operators

# Addition
8 + 2   

# Substraction
10-2    

# Multiplication
7 * 3   

# Devition 
15 / 3  

# Exponentiation
5 ^ 2
5 ** 2

# Modulus (mod) --> Gives the remainder value
70 %% 2
71 %% 2 

# Integer Devision --> Gives the quotient value
70 %/% 2
71 %/% 2
100 %/% 3


# Logical Operations

x = 5
y = 10
z = 7

a = 10
b = 5
c = -1

isTRUE(x == z)

isTRUE(x == b)

isTRUE(a == y)

isTRUE(z == c)

isTRUE(z == z * c)

isTRUE(c < z)

isTRUE(a > b)

isTRUE(x >= y)

isTRUE(z <= b)

isTRUE(x + y == b + a)

isTRUE(z * a == y * c && c * a == c * y)

isTRUE(z * a == y * c || c * a == c * y)

isTRUE(z * a == y * c & c * a == c * y)

isTRUE(z * a == y * c | c * a == c * y)

isTRUE(x != y)

isTRUE(!(z * a == y * c))

isTRUE(!(c * a == c * y))



# Assignment Operators

# Used in local environment

n = 5
m <- 5

# Used in global environment
a <<- 5       # Normally used in functions




# Fundamental Data Objects

# Vector

w <- c(1,2,3,4,5) 
w         # Will get the output as a sequence
class(w)

e <- c(10,20,30,40,50,60)
e
class(e)

r <- c("a","b","c","d","e")
r
class(r)



# Factor

gender <- c(0,1,0,1,0,0,1)
gender
class(gender)  # numeric

Gender <- factor(gender,c(0,1),c("Male","Female"))
Gender
class(Gender)  # factor



# List

p <- c(1,2,3)
q <- "green"
r <- 22

p
q
r

Data <- list(p,q,r)
Data
class(Data)



# Metrix

matrix1 <- matrix(c(1,2,3,4),nrow = 2,ncol = 2,byrow = TRUE)
matrix1
class(matrix1)

matrix2 <- matrix(c(1,2,3,4),nrow = 2,ncol = 2,byrow = FALSE)
matrix2
class(matrix2)



# Data Frame

height <- c(54,89,65,74,32)
weight <- c(41,78,95,64,25)

data_set <- data.frame(height,weight)
data_set

class(data_set)
