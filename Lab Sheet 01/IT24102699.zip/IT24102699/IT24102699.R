getwd()
setwd("C:\\Users\\UsEr\\OneDrive\\Desktop\\IT24102699")
getwd()

      # Exercise

#Question 01
a <- 10
b <- 3



#Question 02
a+b
a%/%b
a%%b
a^b



#Question 03
  #a
a > b

  #b 
b == 3

  #c
a > 5 | b < 2



#Question 04
scores <- c(85,90,78,92,NA,88)
  #a
class(scores)

  #b
mean(scores, na.rm = TRUE)

  #c
(scores[scores > 85 & !is.na(scores)] )



#Question 05
names <- c("Alice", "Bob", "Charlie","Diana", "Evan", "Fiona")
passed <- scores >= 80



#Question 06
results <- data.frame(Name = names, Score = scores, Passed = passed)



#Question 07
str(results)
print(results)



#Question 08
max(results$Score[!is.na(results$Score)])

