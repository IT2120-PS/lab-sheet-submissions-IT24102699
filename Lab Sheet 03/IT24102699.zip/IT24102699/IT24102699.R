                    # Exercise 

getwd()
setwd("F:/SLIIT/_Year_02_/Semester 01/PS - Probability and Statistics/Lab Practicals/Lab 03/IT24102699")
getwd()



student_data <- read.csv("Exercise.csv", header = TRUE)


names(student_data) <- c("Age", "Gender", "Accommodation")
student_data$Gender <- factor(student_data$Gender, 
                              levels = c(1, 2), 
                              labels = c("Male", "Female"))
student_data$Accommodation <- factor(student_data$Accommodation,
                                     levels = c(1, 2, 3),
                                     labels = c("Home", "Boarded", "Lodging"))


summary(student_data$Age)
hist(student_data$Age, 
     main = "Histogram of Student Ages",
     xlab = "Age", 
     ylab = "Frequency",
     col = "lightblue")


gender_table <- table(student_data$Gender)
print(gender_table)
barplot(gender_table, 
        main = "Gender Distribution",
        xlab = "Gender", 
        ylab = "Count",
        col = c("blue", "pink"))


boxplot(Age ~ Accommodation, 
        data = student_data,
        main = "Age Distribution by Accommodation Type",
        xlab = "Accommodation", 
        ylab = "Age",
        col = c("yellow", "lightgreen", "orange"))
